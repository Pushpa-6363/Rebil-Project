    <!--**********************************
        Main wrapper end
    ***********************************-->

    <!--**********************************
        Scripts
    ***********************************-->
    <!-- Required vendors -->
    <script src="<?php echo base_url();?>assets/vendor/global/global.min.js"></script>
	<script src="<?php echo base_url();?>assets/vendor/chart.js/Chart.bundle.min.js"></script>
	<script src="<?php echo base_url();?>assets/vendor/bootstrap-select/dist/js/bootstrap-select.min.js"></script>
	<script src="<?php echo base_url();?>assets/vendor/apexchart/apexchart.js"></script>
	
	<!-- Dashboard 1 -->
	<script src="<?php echo base_url();?>assets/js/dashboard/dashboard-1.js"></script>
	<script src="<?php echo base_url();?>assets/vendor/draggable/draggable.js"></script>
	
	<!-- tagify -->
	<script src="<?php echo base_url();?>assets/vendor/tagify/dist/tagify.js"></script>
	 
	<script src="<?php echo base_url();?>assets/vendor/datatables/js/jquery.dataTables.min.js"></script>
	<script src="<?php echo base_url();?>assets/vendor/datatables/js/dataTables.buttons.min.js"></script>
	<script src="<?php echo base_url();?>assets/vendor/datatables/js/buttons.html5.min.js"></script>
	<script src="<?php echo base_url();?>assets/vendor/datatables/js/jszip.min.js"></script>
	<script src="<?php echo base_url();?>assets/js/plugins-init/datatables.init.js"></script>
   
	<!-- Apex Chart -->
	<script src="<?php echo base_url();?>assets/vendor/bootstrap-datetimepicker/js/moment.js"></script>
	<script src="<?php echo base_url();?>assets/vendor/bootstrap-datetimepicker/js/bootstrap-datetimepicker.min.js"></script>

	<!-- Vectormap -->
    <script src="<?php echo base_url();?>assets/vendor/jqvmap/js/jquery.vmap.min.js"></script>
    <script src="<?php echo base_url();?>assets/vendor/jqvmap/js/jquery.vmap.world.js"></script>
    <script src="<?php echo base_url();?>assets/vendor/jqvmap/js/jquery.vmap.usa.js"></script>
     <script src="<?php echo base_url();?>assets/js/custom.js"></script>
	<script src="<?php echo base_url();?>assets/js/deznav-init.js"></script>
	<script src="<?php echo base_url();?>assets/js/demo.js"></script>
    <script src="<?php echo base_url();?>assets/js/styleSwitcher.js"></script>
	
</body>
</html>